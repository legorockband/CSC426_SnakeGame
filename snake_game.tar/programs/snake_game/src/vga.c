#include "vga.h"

/* address helper function */
static inline uint32_t vga_compute_addr(uint32_t x, uint32_t y) {
    x &= 0x7Fu;   /* x[6:0] */
    y &= 0x3Fu;   /* y[5:0] */
    return (y << 7) | x;
}

void vga_draw_pixel(uint32_t x, uint32_t y, uint32_t color) {
    /*
    Draw pixel on screen
    */
    uint32_t addr = vga_compute_addr(x, y);
    VGA_ADDR      = addr;
    VGA_COLOR_REG = color;
}

void vga_fill(uint32_t color) {

    /*
    fill screen with color 
    */
    for (uint32_t y = 0; y < VGA_HEIGHT; y++) {
        for (uint32_t x = 0; x < VGA_WIDTH; x++) {
            vga_draw_pixel(x, y, color);
        }
    }
}